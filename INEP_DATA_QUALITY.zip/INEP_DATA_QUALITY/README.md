# 📊 Dashboard de Qualidade de Dados (Educação Brasileira)

Este projeto consiste em uma aplicação web interativa em **Streamlit** criada para analisar e evidenciar a qualidade de dados educacionais públicos brasileiros (focada nos Microdados do ENEM).

O sistema investiga a base e gera relatórios dinâmicos sobre **completude**, **consistência**, **validade** e **unicidade** das informações, com o objetivo de demonstrar como furos ou falhas em dados podem afetar diretamente a tomada de decisão para políticas públicas.

## ✨ Funcionalidades
- Carregamento e processamento ágil das colunas selecionadas do ENEM.
- Gráficos e visualizações interativas através da biblioteca **Plotly**.
- Abas analíticas dedicadas às dimensões cruciais de Qualidade de Dados.
- Script gerador de banco sintético robusto (Mock) para fins de simulação e testes do sistema.

## 📁 Estrutura do Repositório
- `app.py`: Arquivo principal da interface executado pelo Streamlit.
- `src/`: 
  - `data_loader.py`: Manipulação e leitura em Pandas.
  - `quality_checks.py`: Regras de negócio das checagens (completude, valores válidos, etc).
  - `visualizations.py`: Funções encapsuladas para compor os componentes visuais.
  - `generate_mock_data.py`: Módulo utilitário que gera um arquivo CSV de testes idêntico à modelagem do INEP para fins demonstrativos.
- `data/`: Diretório base para o armazenamento isolado dos metadados brutos e relatórios de processo.

## 🚀 Como Executar

### Pré-requisitos
- Python 3.9 (ou superior) instalado.

### Inicialização

1. Navegue até a raiz deste projeto e instale as dependências contidas no `requirements.txt`:
   ```bash
   pip install -r requirements.txt
   ```
2. *(Opcional)* Como os arquivos originais do INEP são pesados, você pode criar uma carga de testes gerando dados sintéticos:
   ```bash
   python src/generate_mock_data.py
   ```
   *Isto criará o arquivo de base de dados em `data/raw/enem_2022.csv`.*
3. Inicie o servidor da aplicação:
   ```bash
   python -m streamlit run app.py
   ```
4. O seu navegador padrão e local abrirá o link, mas você pode também digitar diretamente a URL `http://localhost:8501` em seu navegador de preferência.

---

## 👩‍💻 Autora

**Michelle Maria**
*Desenvolvido como projeto analítico de integridade e qualidade de dados educacionais.*
