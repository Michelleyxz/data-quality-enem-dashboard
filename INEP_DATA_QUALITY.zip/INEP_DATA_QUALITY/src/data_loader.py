import pandas as pd
import numpy as np

def load_enem_sample(year=2022, sample_size=100000):
    # Caminho para o arquivo baixado
    file_path = f"data/raw/enem_{year}.csv"
    
    try:
        # Tenta ler o CSV, definindo colunas estritamente
        usecols = ['NU_INSCRICAO', 'NU_NOTA_CN', 'NU_NOTA_CH', 'NU_NOTA_LC', 'NU_NOTA_MT', 'NU_NOTA_REDACAO', 'TP_SEXO', 'NU_IDADE', 'TP_ESCOLA', 'SG_UF_PROVA']
        df = pd.read_csv(file_path, sep=';', encoding='latin1', usecols=usecols, nrows=sample_size)
        
        # O Pandas v2.0+ trata nulls com pd.NA, mas fazemos reposição por precaução
        df.replace({np.nan: None}, inplace=True)
        return df
    except FileNotFoundError:
        print(f"Erro: O arquivo {file_path} não foi encontrado. Geração sintética necessária.")
        return pd.DataFrame()
