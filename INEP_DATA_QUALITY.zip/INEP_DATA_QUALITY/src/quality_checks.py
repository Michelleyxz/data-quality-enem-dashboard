import pandas as pd

def completeness(df, required_columns):
    """Percentual de valores não-nulos por coluna exigida"""
    return df[required_columns].notnull().mean() * 100

def consistency(df, column, rule_func):
    """Aplica uma regra customizada (ex: idade > 0) e retorna % de conformidade"""
    return rule_func(df[column]).mean() * 100

def validity(df, column, allowed_values):
    """Verifica se os valores estão dentro de um conjunto predefinido"""
    return df[column].isin(allowed_values).mean() * 100

def uniqueness(df, key_columns):
    """Verifica linhas duplicadas com base nas colunas-chave"""
    duplicates = df.duplicated(subset=key_columns).sum()
    if len(df) == 0:
        return 0
    return 100 * (1 - duplicates / len(df))
