import pandas as pd
import numpy as np
import os

def generate_mock_enem(filepath, num_rows=50000):
    np.random.seed(42)
    inscricoes = np.arange(1000000, 1000000 + num_rows)
    
    # Simulando notas com dados ausentes
    nota_cn = np.random.normal(500, 100, size=num_rows)
    nota_ch = np.random.normal(520, 90, size=num_rows)
    nota_lc = np.random.normal(510, 85, size=num_rows)
    nota_mt = np.random.normal(530, 110, size=num_rows)
    nota_redacao = np.random.normal(600, 150, size=num_rows)
    
    # Criando valores nulos para simular abstenções
    for arr in [nota_cn, nota_ch, nota_lc, nota_mt]:
        mask = np.random.rand(num_rows) < 0.25 # 25% faltaram
        arr[mask] = np.nan
        
    mask_redacao = np.random.rand(num_rows) < 0.28 # 28% faltaram na redação ou anulada
    nota_redacao[mask_redacao] = np.nan
    
    # Simulando idades com problemas clássicos de qualidade (outliers)
    idades = np.random.normal(18, 5, size=num_rows).astype(int)
    outlier_mask = np.random.rand(num_rows) < 0.01
    idades[outlier_mask] = np.random.choice([5, 120, 200, -5], size=outlier_mask.sum())
    
    # Gênero (M, F e alguns erros)
    sexo = np.random.choice(['M', 'F', 'X', 'Desconhecido'], size=num_rows, p=[0.45, 0.49, 0.02, 0.04])
    
    # Tipo de escola (1, 2, 3 e nulos)
    escola = np.random.choice([1, 2, 3, None], size=num_rows)
    
    # UF
    ufs = ['SP', 'MG', 'RJ', 'BA', 'RS', 'PR', 'PE', 'CE', 'PA', 'MA']
    uf_prova = np.random.choice(ufs, size=num_rows)

    df = pd.DataFrame({
        'NU_INSCRICAO': inscricoes,
        'NU_NOTA_CN': nota_cn,
        'NU_NOTA_CH': nota_ch,
        'NU_NOTA_LC': nota_lc,
        'NU_NOTA_MT': nota_mt,
        'NU_NOTA_REDACAO': nota_redacao,
        'TP_SEXO': sexo,
        'NU_IDADE': idades,
        'TP_ESCOLA': escola,
        'SG_UF_PROVA': uf_prova
    })
    
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    df.to_csv(filepath, sep=';', index=False, encoding='latin1')
    print(f"Dados sintéticos gerados e salvos em {filepath}")

if __name__ == '__main__':
    generate_mock_enem(os.path.join('data', 'raw', 'enem_2022.csv'), num_rows=50000)
