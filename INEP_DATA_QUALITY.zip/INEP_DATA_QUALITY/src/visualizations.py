import plotly.express as px

def plot_missing_by_column(df, title="Valores Ausentes por Coluna"):
    missing = df.isnull().sum().sort_values(ascending=False)
    # Filtra apenas quem tem valores faltantes para o gráfico não focar no zero
    missing = missing[missing > 0]
    
    if len(missing) == 0:
        return px.bar(title="Sem dados ausentes!")
        
    fig = px.bar(x=missing.index, y=missing.values, title=title,
                 labels={'x': 'Colunas', 'y': 'Quantidade Faltante'},
                 color=missing.values, color_continuous_scale='Reds')
    return fig

def plot_score_distribution(df, column, title):
    fig = px.histogram(df, x=column, title=title, nbins=50,
                       marginal="box",
                       color_discrete_sequence=['#1f77b4'])
    return fig
