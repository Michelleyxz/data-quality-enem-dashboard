import streamlit as st
import pandas as pd
from src.data_loader import load_enem_sample
from src.quality_checks import completeness, consistency, validity, uniqueness
from src.visualizations import plot_missing_by_column, plot_score_distribution

st.set_page_config(page_title="Dashboard de Qualidade: Dados da Educação", layout="wide")
st.title("📊 Qualidade de Dados na Educação Brasileira")
st.markdown("Uma análise detalhada dos microdados do ENEM para revelar inconsistências e lacunas que impactam políticas públicas.")

# Carregando dados
@st.cache_data
def load_data(year):
    return load_enem_sample(year, sample_size=50000)

# Barra lateral
st.sidebar.header("Filtros")
selected_year = st.sidebar.selectbox("Ano", [2022, 2021, 2020])

# Tentativa de carregar o dado (fallback para sintético já está no data_loader se modificado, mas o mock será 2022)
df = load_data(selected_year)

if df.empty:
    st.warning(f"Não foi possível carregar os dados de {selected_year}. Execute o script src/generate_mock_data.py para gerar a base sintética baseada em 2022 ou baixe o CSV real para a pasta data/raw.")
else:
    tab1, tab2, tab3, tab4 = st.tabs(["Visão Geral", "Completude", "Consistência & Validade", "História de Impacto"])

    with tab1:
        st.subheader("Snapshot da Base de Dados")
        st.write(f"Exibindo uma amostra de **{len(df)}** registros simulados/amostrados do ENEM {selected_year}.")
        st.dataframe(df.head(100), use_container_width=True)

    with tab2:
        st.subheader("Valores Ausentes por Coluna")
        fig = plot_missing_by_column(df)
        st.plotly_chart(fig, use_container_width=True)
        st.caption("Nota-se que colunas como 'NU_NOTA_REDACAO' possuem uma alta taxa de ausência, o que pode indicar falta no dia da prova ou abstenções.")

    with tab3:
        st.subheader("Consistência na Idade")
        age_valid = (df['NU_IDADE'] >= 10) & (df['NU_IDADE'] <= 80)
        age_compliance = age_valid.mean() * 100
        st.metric("Plausibilidade das Idades (10–80 anos)", f"{age_compliance:.1f}%")
        
        # Verificando idades absurdas
        if not age_valid.all():
            st.warning("Atenção: Existem candidatos com idades fora do limite plausível (Ex: menores de 10 anos ou maiores de 80). Isso demanda higienização nos dados de nascimento do cadastro governamental.")
        
        st.subheader("Validade dos Gêneros")
        gender_valid = df['TP_SEXO'].isin(['F', 'M'])
        gender_compliance = gender_valid.mean() * 100
        st.metric("Gênero Registrado Válido (F e M)", f"{gender_compliance:.1f}%")
        
    with tab4:
        st.subheader("Por que a Qualidade dos Dados é Importante?")
        st.markdown(f"""
        **Exemplo Prático**: A ausência da nota da redação pode levar a uma estimativa inadequada do desempenho global de grupos demográficos.
        Ao ignorarmos valores faltantes, podemos concluir que determinado estado teve desempenho diferente do real.
        Isso afeta de forma letal a distribuição de bolsas (Prouni) e vagas pelo Sisu.
        """)
        
        scores = ['NU_NOTA_CN', 'NU_NOTA_CH', 'NU_NOTA_LC', 'NU_NOTA_MT']
        avg_complete = df[scores].mean()
        # Imputação simples para demonstração
        df_imputed = df[scores].fillna(df[scores].median())
        avg_imputed = df_imputed.mean()
        
        comparison = pd.DataFrame({'Ignorando Nulos (Média Simples)': avg_complete, 'Tratando pela Mediana': avg_imputed})
        st.bar_chart(comparison)
        st.caption("Este é o impacto gerado sobre as estatísticas finais se os dados perdidos não forem corretamente avaliados e tratados metodologicamente.")
